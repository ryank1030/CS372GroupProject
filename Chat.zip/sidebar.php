<?php

session_start();



echo "My name is<br/>";
echo $_SESSION['username'];

?>